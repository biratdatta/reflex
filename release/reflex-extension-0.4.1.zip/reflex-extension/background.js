const l = "content.js", g = "page.js", a = (t) => `${t}/*`, c = (t) => {
  const e = t.replace(/[^a-zA-Z0-9]/g, "_");
  return { page: `reflex_page_${e}`, content: `reflex_content_${e}` };
}, m = async (t) => {
  const e = c(t), n = await chrome.scripting.getRegisteredContentScripts({ ids: [e.page, e.content] });
  n.length !== 2 && (n.length && await chrome.scripting.unregisterContentScripts({ ids: n.map((i) => i.id) }), await chrome.scripting.registerContentScripts([
    // The page runtime is registered first for the same reason the popup injects
    // it first: it should be listening before the content script says hello.
    {
      id: e.page,
      matches: [a(t)],
      js: [g],
      world: "MAIN",
      runAt: "document_idle",
      allFrames: !1,
      persistAcrossSessions: !0
    },
    {
      id: e.content,
      matches: [a(t)],
      js: [l],
      world: "ISOLATED",
      runAt: "document_idle",
      allFrames: !1,
      persistAcrossSessions: !0
    }
  ]));
}, p = (t) => {
  const e = /^(https?:\/\/[^/]+)\/\*$/.exec(t);
  return e ? e[1] : null;
}, r = async () => {
  const e = ((await chrome.permissions.getAll()).origins ?? []).map(p).filter((s) => !!s);
  for (const s of e) await m(s);
  const n = await chrome.scripting.getRegisteredContentScripts(), i = new Set(e.flatMap((s) => Object.values(c(s)))), o = n.filter((s) => s.id.startsWith("reflex_") && !i.has(s.id));
  o.length && await chrome.scripting.unregisterContentScripts({ ids: o.map((s) => s.id) });
}, h = "#1f6f4f", d = async (t, e) => {
  await chrome.action.setBadgeText({ tabId: t, text: e > 0 ? String(e) : "" }), await chrome.action.setBadgeBackgroundColor({ tabId: t, color: h }), await chrome.action.setTitle({
    tabId: t,
    title: e > 0 ? `Reflex — ${e} WebMCP tool${e === 1 ? "" : "s"} active on this page` : "Reflex — discover WebMCP tools on this page"
  });
};
chrome.runtime.onMessage.addListener((t, e, n) => {
  if (t?.type !== "SET_BADGE") return;
  const i = e.tab?.id;
  return typeof i == "number" && d(i, t.count ?? 0), n({ ok: !0 }), !0;
});
chrome.tabs.onUpdated.addListener((t, e) => {
  e.status === "loading" && d(t, 0);
});
chrome.runtime.onInstalled.addListener(() => void r());
chrome.runtime.onStartup.addListener(() => void r());
chrome.permissions.onRemoved.addListener(() => void r());
chrome.permissions.onAdded.addListener(() => void r());
