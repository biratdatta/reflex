const r = "#1f6f4f", i = async (t, e) => {
  await chrome.action.setBadgeText({ tabId: t, text: e > 0 ? String(e) : "" }), await chrome.action.setBadgeBackgroundColor({ tabId: t, color: r }), await chrome.action.setTitle({
    tabId: t,
    title: e > 0 ? `Reflex — ${e} WebMCP tool${e === 1 ? "" : "s"} active on this page` : "Reflex — discover WebMCP tools on this page"
  });
};
chrome.runtime.onMessage.addListener((t, e, a) => {
  if (t?.type !== "SET_BADGE") return;
  const o = e.tab?.id;
  return typeof o == "number" && i(o, t.count ?? 0), a({ ok: !0 }), !0;
});
chrome.tabs.onUpdated.addListener((t, e) => {
  e.status === "loading" && i(t, 0);
});
